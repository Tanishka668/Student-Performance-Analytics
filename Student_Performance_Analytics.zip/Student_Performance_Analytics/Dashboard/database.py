
import mysql.connector
import pandas as pd


def get_connection():
    connection = mysql.connector.connect(
        host="localhost",
        user="root",
        password="tani1234",
        database="student_performance_dw"
    )
    return connection


def get_performance_data():
    connection = get_connection()

    query = """
        SELECT
            ds.school_code,
            dst.studytime,
            dst.failures,
            fp.absences,
            fp.G1,
            fp.G2,
            fp.G3
        FROM fact_student_performance AS fp
        JOIN dim_school AS ds
            ON fp.school_key = ds.school_key
        JOIN dim_study AS dst
            ON fp.study_key = dst.study_key
    """

    df = pd.read_sql(query, connection)
    connection.close()

    return df
