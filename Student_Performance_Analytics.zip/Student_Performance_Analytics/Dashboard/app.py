
import os
import joblib
import pandas as pd
import streamlit as st
import matplotlib.pyplot as plt

from database import get_performance_data


# --------------------------------------------------
# PAGE CONFIGURATION AND DESIGN
# --------------------------------------------------

st.set_page_config(
    page_title="Student Performance Analytics",
    page_icon="🎓",
    layout="wide",
    initial_sidebar_state="expanded"
)

st.markdown("""
<style>
    .stApp {
        background-color: #F5F7FB;
    }

    [data-testid="stSidebar"] {
        background-color: #14243A;
    }

    [data-testid="stSidebar"] * {
        color: #FFFFFF;
    }

    .main-title {
        color: #14243A;
        font-size: 30px;
        font-weight: 750;
        margin-bottom: 2px;
    }

    .subtitle {
        color: #68778D;
        font-size: 15px;
        margin-bottom: 22px;
    }

    [data-testid="stMetric"] {
        background-color: #FFFFFF;
        border: 1px solid #E2E8F0;
        border-radius: 12px;
        padding: 18px 20px;
        box-shadow: 0 2px 8px rgba(20, 36, 58, 0.04);
    }

    [data-testid="stMetricLabel"] {
        color: #64748B;
    }

    [data-testid="stMetricValue"] {
        color: #14243A;
    }

    div[data-testid="stForm"] {
        background-color: #FFFFFF;
        padding: 22px;
        border-radius: 12px;
        border: 1px solid #E2E8F0;
    }

    div.stButton > button,
    div.stFormSubmitButton > button {
        background-color: #14243A;
        color: #FFFFFF;
        border-radius: 8px;
        border: none;
        padding: 8px 18px;
    }

    div.stButton > button:hover,
    div.stFormSubmitButton > button:hover {
        background-color: #28486B;
        color: #FFFFFF;
    }

    h1, h2, h3 {
        color: #14243A;
    }

    hr {
        border-color: #E2E8F0;
    }
</style>
""", unsafe_allow_html=True)


# --------------------------------------------------
# LOAD MYSQL DATA
# --------------------------------------------------

@st.cache_data(ttl=60)
def load_data():
    return get_performance_data()


st.sidebar.markdown("# 🎓 Student Analytics")
st.sidebar.caption("Academic Performance Data Warehouse")
st.sidebar.divider()

try:
    df = load_data()

    if df.empty:
        st.warning("No student records were found in the database.")
        st.stop()

except Exception as e:
    st.error(f"Could not load data from MySQL: {e}")
    st.info(
        "Check that MySQL80 is running and your database.py "
        "connection settings are correct."
    )
    st.stop()


# --------------------------------------------------
# SIDEBAR NAVIGATION AND FILTERS
# --------------------------------------------------

page = st.sidebar.radio(
    "NAVIGATION",
    [
        "Overview",
        "Student Analytics",
        "Predict Grade",
        "Student Records"
    ]
)

st.sidebar.divider()
st.sidebar.markdown("### Filter Analytics")

school_options = ["All"] + sorted(
    df["school_code"].dropna().unique().tolist()
)

selected_school = st.sidebar.selectbox(
    "School",
    school_options
)

study_options = sorted(
    df["studytime"].dropna().unique().tolist()
)

selected_study = st.sidebar.selectbox(
    "Weekly Study Time",
    ["All"] + study_options,
    format_func=lambda x: (
        "All study-time groups"
        if x == "All"
        else {
            1: "Less than 2 hours",
            2: "2–5 hours",
            3: "5–10 hours",
            4: "More than 10 hours"
        }.get(x, str(x))
    )
)

filtered_df = df.copy()

if selected_school != "All":
    filtered_df = filtered_df[
        filtered_df["school_code"] == selected_school
    ]

if selected_study != "All":
    filtered_df = filtered_df[
        filtered_df["studytime"] == selected_study
    ]

st.sidebar.divider()
st.sidebar.caption("Data source: MySQL Data Warehouse")


# --------------------------------------------------
# PAGE 1: OVERVIEW
# --------------------------------------------------

if page == "Overview":

    st.markdown(
        '<div class="main-title">Student Performance Dashboard</div>',
        unsafe_allow_html=True
    )
    st.markdown(
        '<div class="subtitle">'
        'Monitor academic outcomes and explore student performance.'
        '</div>',
        unsafe_allow_html=True
    )

    if filtered_df.empty:
        st.warning("No records match the selected filters.")
        st.stop()

    total_students = len(filtered_df)
    average_grade = filtered_df["G3"].mean()
    highest_grade = filtered_df["G3"].max()
    total_absences = filtered_df["absences"].sum()

    c1, c2, c3, c4 = st.columns(4)

    c1.metric("👥 Total Students", f"{total_students:,}")
    c2.metric("📊 Average Final Grade", f"{average_grade:.2f} / 20")
    c3.metric("🏆 Highest Final Grade", f"{highest_grade:.0f} / 20")
    c4.metric("📅 Total Absences", f"{total_absences:,.0f}")

    st.write("")
    st.subheader("Academic Performance Overview")

    left, right = st.columns(2)

    with left:
        st.markdown("#### Final Grade Distribution")

        fig, ax = plt.subplots(figsize=(7, 4))
        ax.hist(
            filtered_df["G3"],
            bins=11,
            edgecolor="white",
            color="#416A9C"
        )
        ax.set_xlabel("Final Grade (0–20)")
        ax.set_ylabel("Number of Students")
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)
        ax.grid(axis="y", alpha=0.2)
        st.pyplot(fig)
        plt.close(fig)

    with right:
        st.markdown("#### Average Grade by Study Time")

        study_results = (
            filtered_df.groupby("studytime")["G3"]
            .mean()
            .reset_index()
        )

        study_results["Study Group"] = study_results["studytime"].map({
            1: "Under 2 hrs",
            2: "2–5 hrs",
            3: "5–10 hrs",
            4: "Over 10 hrs"
        }).fillna(study_results["studytime"].astype(str))

        st.bar_chart(
            study_results,
            x="Study Group",
            y="G3",
            color="#2D8B83"
        )

    st.markdown("#### Average Grade by Previous Failures")

    failure_results = (
        filtered_df.groupby("failures")["G3"]
        .mean()
        .reset_index()
    )

    failure_results["failures"] = (
        failure_results["failures"].astype(str)
    )

    st.bar_chart(
        failure_results,
        x="failures",
        y="G3",
        color="#416A9C"
    )

    st.caption(
        "Use the sidebar filters to explore different student groups. "
        "These relationships are descriptive and do not prove causation."
    )


# --------------------------------------------------
# PAGE 2: STUDENT ANALYTICS
# --------------------------------------------------

elif page == "Student Analytics":

    st.markdown(
        '<div class="main-title">Student Analytics</div>',
        unsafe_allow_html=True
    )
    st.markdown(
        '<div class="subtitle">'
        'Compare academic outcomes across study habits and past failures.'
        '</div>',
        unsafe_allow_html=True
    )

    if filtered_df.empty:
        st.warning("No records match the selected filters.")
        st.stop()

    left, right = st.columns(2)

    with left:
        st.markdown("#### Grade Distribution")

        fig, ax = plt.subplots(figsize=(7, 4))
        ax.hist(
            filtered_df["G3"],
            bins=11,
            color="#416A9C",
            edgecolor="white"
        )
        ax.set_xlabel("Final Grade")
        ax.set_ylabel("Students")
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)
        ax.grid(axis="y", alpha=0.2)
        st.pyplot(fig)
        plt.close(fig)

    with right:
        st.markdown("#### Grade by Previous Failures")

        failure_results = (
            filtered_df.groupby("failures")["G3"]
            .mean()
            .reset_index()
        )
        failure_results["failures"] = (
            failure_results["failures"].astype(str)
        )

        st.bar_chart(
            failure_results,
            x="failures",
            y="G3",
            color="#D19A43"
        )

    st.markdown("#### Grade by Study Time")

    study_results = (
        filtered_df.groupby("studytime")["G3"]
        .mean()
        .reset_index()
    )

    st.bar_chart(
        study_results,
        x="studytime",
        y="G3",
        color="#2D8B83"
    )

    st.markdown("#### Summary Statistics")

    summary = filtered_df[
        ["G1", "G2", "G3", "absences", "failures"]
    ].describe().round(2)

    st.dataframe(summary, use_container_width=True)


# --------------------------------------------------
# PAGE 3: PREDICT STUDENT PERFORMANCE
# --------------------------------------------------

elif page == "Predict Grade":

    st.markdown(
        '<div class="main-title">Predict Student Performance</div>',
        unsafe_allow_html=True
    )
    st.markdown(
        '<div class="subtitle">'
        'Estimate a final grade using the trained Linear Regression model.'
        '</div>',
        unsafe_allow_html=True
    )

    model_path = os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
        "models",
        "student_performance_model.pkl"
    )

    try:
        saved_data = joblib.load(model_path)
        trained_model = saved_data["model"]
        feature_names = saved_data["feature_names"]

        with st.form("prediction_form"):

            st.markdown("#### Student Information")
            col1, col2 = st.columns(2)

            with col1:
                school = st.selectbox("School", ["GP", "MS"])
                sex = st.selectbox("Sex", ["F", "M"])
                age = st.slider("Age", 15, 22, 17)
                address = st.selectbox("Home Address", ["U", "R"])
                famsize = st.selectbox("Family Size", ["GT3", "LE3"])
                Pstatus = st.selectbox("Parents' Status", ["T", "A"])

                Medu = st.selectbox(
                    "Mother's Education", [0, 1, 2, 3, 4]
                )
                Fedu = st.selectbox(
                    "Father's Education", [0, 1, 2, 3, 4]
                )

                Mjob = st.selectbox(
                    "Mother's Job",
                    ["teacher", "health", "services", "at_home", "other"]
                )
                Fjob = st.selectbox(
                    "Father's Job",
                    ["teacher", "health", "services", "at_home", "other"]
                )
                reason = st.selectbox(
                    "Reason for School Choice",
                    ["home", "reputation", "course", "other"]
                )
                guardian = st.selectbox(
                    "Guardian", ["mother", "father", "other"]
                )

            with col2:
                traveltime = st.selectbox(
                    "Travel Time", [1, 2, 3, 4]
                )
                studytime = st.selectbox(
                    "Weekly Study Time", [1, 2, 3, 4]
                )
                failures = st.selectbox(
                    "Past Class Failures", [0, 1, 2, 3]
                )

                schoolsup = st.selectbox(
                    "School Support", ["no", "yes"]
                )
                famsup = st.selectbox(
                    "Family Support", ["no", "yes"]
                )
                paid = st.selectbox(
                    "Extra Paid Classes", ["no", "yes"]
                )
                activities = st.selectbox(
                    "Extracurricular Activities", ["no", "yes"]
                )
                nursery = st.selectbox(
                    "Attended Nursery School", ["no", "yes"]
                )
                higher = st.selectbox(
                    "Wants Higher Education", ["no", "yes"]
                )
                internet = st.selectbox(
                    "Internet at Home", ["no", "yes"]
                )
                romantic = st.selectbox(
                    "Romantic Relationship", ["no", "yes"]
                )

            st.markdown("#### Lifestyle and Attendance")

            c1, c2, c3 = st.columns(3)

            with c1:
                famrel = st.slider("Family Relationship", 1, 5, 4)
                freetime = st.slider("Free Time", 1, 5, 3)

            with c2:
                goout = st.slider("Going Out", 1, 5, 3)
                Dalc = st.slider(
                    "Workday Alcohol Scale", 1, 5, 1
                )

            with c3:
                Walc = st.slider(
                    "Weekend Alcohol Scale", 1, 5, 1
                )
                health = st.slider("Health Scale", 1, 5, 3)

            absences = st.number_input(
                "Number of Absences",
                min_value=0,
                max_value=100,
                value=0
            )

            submitted = st.form_submit_button(
                "🎯 Predict Final Grade",
                use_container_width=True
            )

        if submitted:

            input_data = pd.DataFrame([{
                "school": school,
                "sex": sex,
                "age": age,
                "address": address,
                "famsize": famsize,
                "Pstatus": Pstatus,
                "Medu": Medu,
                "Fedu": Fedu,
                "Mjob": Mjob,
                "Fjob": Fjob,
                "reason": reason,
                "guardian": guardian,
                "traveltime": traveltime,
                "studytime": studytime,
                "failures": failures,
                "schoolsup": schoolsup,
                "famsup": famsup,
                "paid": paid,
                "activities": activities,
                "nursery": nursery,
                "higher": higher,
                "internet": internet,
                "romantic": romantic,
                "famrel": famrel,
                "freetime": freetime,
                "goout": goout,
                "Dalc": Dalc,
                "Walc": Walc,
                "health": health,
                "absences": absences
            }])

            encoded_input = pd.get_dummies(
                input_data,
                drop_first=True,
                dtype=int
            )

            encoded_input = encoded_input.reindex(
                columns=feature_names,
                fill_value=0
            )

            prediction = float(
                trained_model.predict(encoded_input)[0]
            )

            st.divider()
            st.subheader("Prediction Result")

            st.metric(
                "Estimated Final Grade",
                f"{prediction:.2f} / 20"
            )

            st.progress(
                max(0.0, min(1.0, prediction / 20))
            )

            st.caption(
                "The progress bar represents the predicted score relative "
                "to 20, not the model's confidence. This estimate has "
                "limited predictive accuracy and is not a guaranteed result."
            )

    except FileNotFoundError:
        st.error(
            "Model file not found. Check the models folder and "
            "student_performance_model.pkl."
        )

    except Exception as e:
        st.error(f"Could not load or run the prediction model: {e}")


# --------------------------------------------------
# PAGE 4: STUDENT RECORDS
# --------------------------------------------------

elif page == "Student Records":

    st.markdown(
        '<div class="main-title">Student Records</div>',
        unsafe_allow_html=True
    )
    st.markdown(
        '<div class="subtitle">'
        'Browse the student records stored in the MySQL data warehouse.'
        '</div>',
        unsafe_allow_html=True
    )

    if filtered_df.empty:
        st.warning("No records match the selected filters.")
        st.stop()

    st.metric("Matching Records", f"{len(filtered_df):,}")

    search_text = st.text_input(
        "Search school code",
        placeholder="Enter a school code, e.g. GP"
    )

    records_to_show = filtered_df.copy()

    if search_text.strip():
        records_to_show = records_to_show[
            records_to_show["school_code"]
            .astype(str)
            .str.contains(search_text.strip(), case=False, na=False)
        ]

    st.dataframe(
        records_to_show.reset_index(drop=True),
        use_container_width=True,
        hide_index=True
    )

    st.download_button(
        "Download displayed records as CSV",
        data=records_to_show.to_csv(index=False).encode("utf-8"),
        file_name="student_performance_records.csv",
        mime="text/csv"
    )

    st.caption(
        "The records shown here come from the existing MySQL query."
    )


# --------------------------------------------------
# FOOTER
# --------------------------------------------------

st.divider()
st.caption(
    "Student Performance Analytics | MySQL Data Warehouse + "
    "Linear Regression | Academic analysis only"
)
