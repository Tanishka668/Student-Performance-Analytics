CREATE DATABASE IF NOT EXISTS student_performance_dw;

USE student_performance_dw;
USE student_performance_dw;

CREATE TABLE dim_student (
    student_key INT AUTO_INCREMENT PRIMARY KEY,
    sex VARCHAR(10),
    age INT,
    address VARCHAR(10),
    famsize VARCHAR(10),
    Pstatus VARCHAR(10),
    guardian VARCHAR(20)
);

CREATE TABLE dim_school (
    school_key INT AUTO_INCREMENT PRIMARY KEY,
    school_code VARCHAR(10) UNIQUE
);

CREATE TABLE dim_study (
    study_key INT AUTO_INCREMENT PRIMARY KEY,
    studytime INT,
    traveltime INT,
    failures INT,
    schoolsup VARCHAR(5),
    famsup VARCHAR(5),
    paid VARCHAR(5),
    activities VARCHAR(5),
    higher_education VARCHAR(5),
    internet VARCHAR(5)
);

CREATE TABLE fact_student_performance (
    performance_key INT AUTO_INCREMENT PRIMARY KEY,
    student_key INT NOT NULL,
    school_key INT NOT NULL,
    study_key INT NOT NULL,
    absences INT,
    G1 INT,
    G2 INT,
    G3 INT,
    FOREIGN KEY (student_key)
        REFERENCES dim_student(student_key),
    FOREIGN KEY (school_key)
        REFERENCES dim_school(school_key),
    FOREIGN KEY (study_key)
        REFERENCES dim_study(study_key)
);
SHOW TABLES;
DESCRIBE dim_student;
DESCRIBE dim_school;
DESCRIBE dim_study;
DESCRIBE fact_student_performance;
USE student_performance_dw;

SHOW TABLES;
SELECT COUNT(*) AS total_students FROM dim_student;

SELECT COUNT(*) AS total_schools FROM dim_school;

SELECT COUNT(*) AS total_study_records FROM dim_study;

SELECT COUNT(*) AS total_performance_records
FROM fact_student_performance;

CREATE TABLE staging_student_data (
    school VARCHAR(10),
    sex VARCHAR(10),
    age INT,
    address VARCHAR(10),
    famsize VARCHAR(10),
    Pstatus VARCHAR(10),
    Medu INT,
    Fedu INT,
    Mjob VARCHAR(30),
    Fjob VARCHAR(30),
    reason VARCHAR(30),
    guardian VARCHAR(20),
    traveltime INT,
    studytime INT,
    failures INT,
    schoolsup VARCHAR(5),
    famsup VARCHAR(5),
    paid VARCHAR(5),
    activities VARCHAR(5),
    nursery VARCHAR(5),
    higher VARCHAR(5),
    internet VARCHAR(5),
    romantic VARCHAR(5),
    famrel INT,
    freetime INT,
    goout INT,
    Dalc INT,
    Walc INT,
    health INT,
    absences INT,
    G1 INT,
    G2 INT,
    G3 INT
);

SHOW TABLES;

DESCRIBE staging_student_data;
USE student_performance_dw;

SELECT COUNT(*) AS total_records
FROM staging_student_data;
SELECT *
FROM staging_student_data
LIMIT 10;

SELECT
    SUM(school IS NULL) AS missing_school,
    SUM(studytime IS NULL) AS missing_studytime,
    SUM(absences IS NULL) AS missing_absences,
    SUM(G3 IS NULL) AS missing_final_grade
FROM staging_student_data;

#Now here the project starts.

