USE student_performance_dw;

SELECT COUNT(*) AS total_records
FROM staging_student_data;

ALTER TABLE staging_student_data
ADD COLUMN staging_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY FIRST
SELECT staging_id, school, sex, age, studytime, G3
FROM staging_student_data
LIMIT 10;

ALTER TABLE dim_student
ADD COLUMN source_row_id INT UNIQUE; 

INSERT INTO dim_student
    (source_row_id, sex, age, address, famsize, Pstatus, guardian)
SELECT
    staging_id, sex, age, address, famsize, Pstatus, guardian
FROM staging_student_data; 

SELECT COUNT(*) AS total_students
FROM dim_student; 

INSERT INTO dim_school (school_code)
SELECT DISTINCT school
FROM staging_student_data; 

SELECT * FROM dim_school;
INSERT INTO dim_study (
    studytime,
    traveltime,
    failures,
    schoolsup,
    famsup,
    paid,
    activities,
    higher_education,
    internet
)
SELECT DISTINCT
    studytime,
    traveltime,
    failures,
    schoolsup,
    famsup,
    paid,
    activities,
    higher,
    internet
FROM staging_student_data;

SELECT COUNT(*) AS total_study_combinations
FROM dim_study;

SELECT COUNT(*) AS student_records FROM dim_student;

SELECT COUNT(*) AS school_records FROM dim_school;

SELECT COUNT(*) AS study_records FROM dim_study;

USE student_performance_dw;

INSERT INTO fact_student_performance (
    student_key,
    school_key,
    study_key,
    absences,
    G1,
    G2,
    G3
)
SELECT
    ds.student_key,
    dsch.school_key,
    dst.study_key,
    st.absences,
    st.G1,
    st.G2,
    st.G3
FROM staging_student_data AS st
JOIN dim_student AS ds
    ON ds.source_row_id = st.staging_id
JOIN dim_school AS dsch
    ON dsch.school_code = st.school
JOIN dim_study AS dst
    ON dst.studytime = st.studytime
    AND dst.traveltime = st.traveltime
    AND dst.failures = st.failures
    AND dst.schoolsup = st.schoolsup
    AND dst.famsup = st.famsup
    AND dst.paid = st.paid
    AND dst.activities = st.activities
    AND dst.higher_education = st.higher
    AND dst.internet = st.internet;
    
   SELECT COUNT(*) AS total_performance_records
FROM fact_student_performance; 

SELECT *
FROM fact_student_performance
LIMIT 10;

SELECT
    COUNT(*) AS total_students,
    ROUND(AVG(G3), 2) AS average_final_grade,
    MIN(G3) AS lowest_grade,
    MAX(G3) AS highest_grade
FROM fact_student_performance;

SELECT
    ds.school_code,
    ROUND(AVG(fp.G3), 2) AS average_final_grade,
    COUNT(*) AS student_count
FROM fact_student_performance AS fp
JOIN dim_school AS ds
    ON fp.school_key = ds.school_key
GROUP BY ds.school_code;

SELECT
    dst.studytime,
    ROUND(AVG(fp.G3), 2) AS average_final_grade,
    COUNT(*) AS student_count
FROM fact_student_performance AS fp
JOIN dim_study AS dst
    ON fp.study_key = dst.study_key
GROUP BY dst.studytime
ORDER BY dst.studytime;

